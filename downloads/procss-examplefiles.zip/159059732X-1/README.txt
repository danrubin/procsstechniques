################################################
#
# Code samples for:
# Pro CSS Techniques
# by Jeff Croft, Ian Lloyd, and Dan Rubin
#
################################################

Version: 1.0
Last updated: 10/23/2006

Version History:
----------------

1.0, 10/23/2006
- Initial Release